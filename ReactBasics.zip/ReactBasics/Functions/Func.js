export function Func() {
    return <h2>Hi, I am also a Car!</h2>;
  }

  export function UserGreeting(props) {
    return <h1>Welcome back!</h1>;
  }
  
  export function GuestGreeting(props) {
    return <h1>Please sign up.</h1>;
  }

  export function Greeting(props) {
    const isLoggedIn = props.isLoggedIn;
    if (isLoggedIn) {
      return <UserGreeting />;
    }
    return <GuestGreeting />;
  }

export default Greeting;
//export default Func;