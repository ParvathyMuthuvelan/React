import logo from './logo.svg';
import './App.css';
import {Home} from './Components/Home';
import {AboutUs} from './Components/AboutUs';

function App() {
  return (
    <div className="App">
      <h3>Welcome to React</h3>
      <Home />
      <AboutUs/>
    </div>
  );
}

export default App;
