import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import Func from './Functions/Func';
import Greeting from './Functions/Func';
import {Car} from './Components/Car';
import {Ccar} from './Components/Car';
import {Toggle} from './Components/Toggle';
import {Garage} from './Components/Car';
import reportWebVitals from './reportWebVitals';

//ReactDOM.render(element4, document.getElementById('root'));
//ReactDOM.render(<App/>, document.getElementById('root'));
//ReactDOM.render(<Car/>, document.getElementById('root'));
//ReactDOM.render(<Func/>, document.getElementById('root'));
//ReactDOM.render(<Car brand="Maruti"/>, document.getElementById('root'));
//ReactDOM.render(<Garage/>, document.getElementById('root'));
//ReactDOM.render(<Ccar/>, document.getElementById('root'));
ReactDOM.render(<Toggle/>, document.getElementById('root'));

//conditional rendering
/*ReactDOM.render(
  // Try changing to isLoggedIn={true}:
  <Greeting isLoggedIn={false} />,
  document.getElementById('root')
);*/
//hands on
export class Cart extends React.Component {
  render() {
    return (<table>
    {this.props.item.map((item) => (
        <tr><td> {item.itemname}</td> 
        <td>{item.price}</td></tr>
    ))}
    </table>);
}
}

export class Onlineshopping extends React.Component
{
    render()
    {
        const CartInfo=[{itemname:"Laptop",price:80000},
        {itemname:"TV",price:120000},
        {itemname:"Washing machine",price:70000},
        {itemname:"Fridge",price:50000}
    ];
    return(
        <div className="mydiv">
            <h1>Items Ordered:</h1>
            <Cart item={CartInfo}/>
        </div>
    );
    }

}
//ReactDOM.render(<Onlineshopping/>, document.getElementById('root'));

//JSX
const element = <h1>Hello, world</h1>;
const myelement = <h1>React is {5 + 5} times better with JSX</h1>;
const element1 = (
  <ul>
    <li>Apples</li>
    <li>Bananas</li>
    <li>Cherries</li>
  </ul>
);
const element2 = (
  <div>
    <h1>I am a Header.</h1>
    <h1>I am a Header too.</h1>
  </div>
);
const element3 = <input type="text" />;
const name = 'Sai';
const myelement1 = <h1>Hello, {name}</h1>;
function formatName(user) {
  return user.firstName + ' ' + user.lastName;
}

const user = {
  firstName: 'Sai',
  lastName: 'Sri'
};

const element4= (
  <h1>
    Hello, {formatName(user)}!
  </h1>
);
function getGreeting(user) {
  if (user) {
    return <h1>Hello, {formatName(user)}!</h1>;
  }
  return <h1>Hello, Stranger.</h1>;
}
const myelement2= (
  <h1>
    Hello, {getGreeting(user)}!
  </h1>
);
var HTMLLi = React.createElement('li', {className:'bar'}, 'test');
//ReactDOM.render(HTMLLi, document.getElementById('root'));

var inlineStyles = {backgroundColor:'red', fontSize:20};
var reactNodeLi =  React.createElement('div',{style:inlineStyles}, 'styled')

//ReactDOM.render(reactNodeLi, document.getElementById('root'));
var nav = (
  <ul id="nav">
    <li><a href="#">Home</a></li>
    <li><a href="#">About</a></li>
    <li><a href="#">Clients</a></li>
    <li><a href="#">Contact Us</a></li>
  </ul>
);
//ReactDOM.render(nav, document.getElementById('root'));

var styles = {
	color:'red',
	backgroundColor:'black',
	fontWeight:'bold'
};

var reactNode = <div style={styles}>test</div>;

//ReactDOM.render(reactNode, document.getElementById('root'));


