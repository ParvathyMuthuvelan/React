import React,{Component} from 'react';
 class AboutUs extends Component{
    render(){
    return(
        <div><h3>About Us</h3></div>
    );
    }
}

//state ,props-attribute passed to a html