import React,{Component} from 'react';
/*export class Car extends Component {
    constructor() {
      super();
      this.state = {color: "blue"};
    }
    render() {
      return <h2>I am a {this.state.color} Car!</h2>;
    }
  }*/
  export class Car extends Component {
    render() {
      return <h2>Brand is {this.props.brand}!</h2>;
    }
  }
  export class Garage extends Component {
    render() {
      return (
        <div>
        <h1>Garage has Car</h1>
        <Car brand="Maruti"/>
        </div>
      );
    }
  }
  export class Ccar extends Component {
    constructor(props) {
      super(props);
      this.state = {
        brand: "Ford",
        model: "Mustang",
        color: "red",
        year: 1964
      };
    }
    changeColor = () => {
      this.setState({color: "blue"});
    }
    render() {
      return (
        <div>
          <h1>My {this.state.brand}</h1>
          <p>
            It is a {this.state.color}
            {this.state.model}
            from {this.state.year}.
          </p>
          <button
            type="button"
            onClick={this.changeColor}
          >Change color</button>
        </div>
      );
    }
  }
  //export default Garage;