import React from 'react';
import './App.css';
import { Link } from 'react-router-dom';

import {BrowserRouter as Routes, Route }from 'react-router-dom';
import Home from './components/Home';
import Aboutus from './components/Aboutus';
import Contact from './components/Contact';
import Register from './components/Register';
import ProductListComponent from './components/ProductListComponent';
function App() {
  

  return (
    <div>
       
                <div className="container">
                
                    <Routes> 
                          <Route path = "/" exact component = {Home}></Route>
                          <Route path = "/about" exact component = {Aboutus}></Route>
                          <Route path = "/contact"  exact component = {Contact}></Route>
                          <Route path = "/register"  exact component = {Register}></Route>
                          <Route path = "/products"  component = {ProductListComponent}></Route>
                    </Routes>
                  
                </div>
                {/*<FooterComponent className="footer--pin"/>*/}
        
    </div>
    
  );
}


export default App;

/*function App() {
  const greeting = 'Hello Function Component!';

  return <h1>{greeting}</h1>;
  
}*/

