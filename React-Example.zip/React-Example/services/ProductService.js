import axios from 'axios';



class ProductService {
   // products=[]
    
 

    getProducts(){
        console.log("method called")
    
      return axios.get('./data.json')
       //this.products;
     // console.log("Products list")
    }
   
}
    export default new ProductService();