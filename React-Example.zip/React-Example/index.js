import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import TodoContainer from "./components/TodoContainer"
import Car from "./components/Car"
//const x = (x, y) => {return (x * y)};
//Array.
const myArray = ['apple', 'banana', 'orange'];
const myList = myArray.map((item) => <p>{item}</p>)
//ReactDOM.render(myList,document.getElementById('root'));


const cartInfo=[{itemname:"Laptop",price:80000},
{itemname:"TV",price:120000},
{itemname:"Washing machine",price:70000},
{itemname:"Fridge",price:50000}];


 const cart= cartInfo.map((prod) =>  <table >
   <tr><td>{prod.itemname}</td>
   <td>{prod.price}</td></tr> 
   </table>)
 //ReactDOM.render(cart,document.getElementById('root'));


/*ReactDOM.render(
  <App/>, document.getElementById('root'));*/


/*function Car() {
  return (<h2> Testing function component
    Hi, I am a Car!</h2>
           
  );
}*/
/*class Car extends React.Component {
  constructor(props) {
    super(props);
    this.state = {color: "blue", model: "2020"};
  }
  render() {
    return <h2>I am a  {this.props.brand} {this.state.color} Car! of model {this.state.model}</h2>;
  }
}
ReactDOM.render(<Car brand="suzuki"/>, document.getElementById('root'));*/

/*function Car(props) {
  return <h2>I am a {props.color} Car! of model {props.model}</h2>;
}*/

/* Nesting functions 
function Car(props) {
  return <h2>I am a { props.brand }!</h2>;
}

function Garage() {
  return (
    <>
	    <h1></h1>
	    <Car brand="Ford" />
    </>
  );
}

ReactDOM.render(<Garage />, document.getElementById('root'));*/

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);


//ReactDOM.render(<Car color="yellow" model="2021"/>, document.getElementById('root'));


/*ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);*/
// Event handling
/*function Message() {
  const msg = () => {
    alert("Event triggered!");
  }

  return (
    <button onClick={msg}>Click</button>
  );
}

ReactDOM.render(<Message />, document.getElementById('root')); */


/*function Message() {
  const msg = (a) => {
    alert(a);
  }

  return (
    <button onClick={() => msg("Hai")}>Click</button>
  );
}

ReactDOM.render(<Message />, document.getElementById('root'));*/


//Event Object
function Message() {
  const msg = (a, b) => {
    alert(b.type);
    console.log(b);
	
  }

  return (
    <button onClick={(event) => msg("Hi", event)}>Click</button>
  );
}

//ReactDOM.render(<Message />, document.getElementById('root'));

//conditional rendering
function Welcome() {
	return <h1>Welcome</h1>;
}

function Login() {
	return <h1>Login to get access</h1>;
}

function CheckLogin(props) {
  const isLoggedIn = props.isLogged;
  if (isLoggedIn) {
    return <Welcome/>;
  }
  return <Login/>;
}

//ReactDOM.render(  <CheckLogin isLogged={false} />,  document.getElementById('root'));

//Ex:2
function LoginCheck(props) {
  const isLogin = props.isLoggedIn;
	return (
		<>
			{ isLogin ? <Welcome/> : <Login/> }
		</>
	);
}
//ReactDOM.render(
  //<LoginCheck isLoggedIn={true} />, document.getElementById('root'));
//Example2
function Garage(props) {
  const cars = props.cars;
  return (
    <>
      <h1>Garage</h1>
      {cars.length >= 2 &&
        <h2>
          You have {cars.length} cars in your garage.
        </h2>
      }
    </>
  );
}

const cars = ['Ford', 'BMW'];

//ReactDOM.render(  <Garage cars={cars} />,   document.getElementById('root'));


//ReactDOM.render(<TodoContainer />, document.getElementById("root"));
//ReactDOM.render(<Car />, document.getElementById('root'));
reportWebVitals();
