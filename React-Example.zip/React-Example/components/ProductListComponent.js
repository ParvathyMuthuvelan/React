import React, { Component } from 'react'

import ProductService from '../services/ProductService'



class ProductListComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                products: [],
                
        }
       
    }
  


    componentDidMount(){
        
       ProductService.getProducts().then(res => {
        this.setState({products: res.data});
    })
}
            
   
        
    

 

    render() {
       
        return (
            <div>
                
                <h3> Shopping Made easy </h3>
                
                 <h2 className="text-center">Product List</h2>
                
                <br></br> 
                <div className = "row">
                        <table className = "table table-striped table-bordered">

                            <thead>
                                <tr>
                                    <th> Product Name</th>
                                    <th> Product Price</th>
                                    <th> Category</th>
                                    <th> Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.products.map(
                                        product => 
                                        <tr key = {product.id}>
                                             <td> {product.name} </td>   
                                             <td> {product.price}</td>
                                             <td> {product.category}</td>
                                             <td>
                                                 <button onClick={ () => this.addProduct(product.id)} className="btn btn-dark">Add Product </button>
                                                 
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.viewCart(product.id)} className="btn btn-dark">View Cart </button>
                                             </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                            </table>

                            </div> 

            </div>
        )
    }
}

export default ProductListComponent