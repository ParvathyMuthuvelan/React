import React from 'react';
 
function About () {
    return <div>
        <h2>Welcome </h2>
 
        Read more about us at :
        <a href="www.google.com">
            Click
        </a>
    </div>
}
export default About;