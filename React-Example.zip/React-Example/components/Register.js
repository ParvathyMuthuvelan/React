import React from 'react';
import ReactDOM from 'react-dom';

export class Register extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userName: '',
      age: null,
      address: '',
      country: 'US',
      gender: ''
    };
        this.changeHandler = this.changeHandler.bind(this);
        this.saveUser = this.saveUser.bind(this);
  }
  changeHandler = (event) => {
    let name = event.target.name;
    let value = event.target.value;
    this.setState({[name]: value});
   
    //alert(nam +" "+val)
  }
 
  saveUser = (e) => {
    e.preventDefault();
    let user = {userName: this.state.userName, age: this.state.age, gender: this.state.gender,address: this.state.address,country:this.state.country};
    console.log('User => ' + JSON.stringify(user));
    alert('User => ' + JSON.stringify(user));
   
  }
  render() {
    return (  
      <div>
       
      <form >
     
      <p>Name:</p>
      <input
        type='text'
        name='userName' 
        onChange={this.changeHandler}
      />
      <p>Age:</p>
      <input
        type='text'
        name='age' 
        onChange={this.changeHandler}
      />
      <br/>
      <p>Address:</p>
      <textarea name="address" value={this.state.address} onChange={this.changeHandler}/>
      <br/>
      <p>Country:</p>
      <select name="country" value={this.state.country} onChange={this.changeHandler}>
        <option value="India">India</option>
        <option value="US">US</option>
        <option value="UK">UK</option>
      </select> <br></br>
      <p>Gender:</p>
            <input type="radio" name="gender" value="Female"  checked="checked" onChange={this.changeHandler}/>Female
            <input type="radio" name="gender" value="Male"   onChange={this.changeHandler}/>Male
         
      <input type='submit' onClick={this.saveUser}/>
      </form>
      </div>
    );
  }
}
export default Register;