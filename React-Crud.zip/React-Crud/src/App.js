import React from 'react';
import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import ListEmployeeComponent from './components/ListEmployeeComponent';
import HeaderComponent from './components/HeaderComponent';
import FooterComponent from './components/FooterComponent';
import CreateEmployeeComponent from './components/CreateEmployeeComponent';
import ViewEmployeeComponent from './components/ViewEmployeeComponent';
import LoginComponent from './components/LoginComponent';
import HelpComponent from './components/HelpComponent';
import Register from './components/Register';
function App() {
  return (
    <div>
        <Router>
              <HeaderComponent />
                <div className="container">
                    <Switch> 
                          <Route path = "/" exact component = {LoginComponent}></Route>
                          <Route path = "/help"  component = {HelpComponent}></Route>
                          <Route path = "/signup"  component = {Register}></Route>
                          <Route path = "/employees" component = {ListEmployeeComponent}></Route>
                         <Route path = "/add-employee/:id" component = {CreateEmployeeComponent}></Route>
                         <Route path = "/view-employee/:id" component = {ViewEmployeeComponent}></Route>
                         
                    </Switch>
                  
                </div>
                <FooterComponent className="footer--pin"/>
        </Router>
    </div>
    
  );
}

export default App;
