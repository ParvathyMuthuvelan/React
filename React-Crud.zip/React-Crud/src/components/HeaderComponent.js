import React, { Component } from 'react'
import LoginComponent from './LoginComponent'
import { Link } from 'react-router-dom';
import logo from './logo192.png';
class HeaderComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 
        }
    }

    render() {
        return (
            <div>
               <header>
                  
                    <nav className="navbar navbar-expand-md navbar-dark bg-dark">
                    <img src={logo}/>
                    <div><a href="/emp" className="navbar-brand">Employee Management App</a>
                   
                   <li> <Link to="/help">Help</Link></li>
                   
                    <li><Link to="/signup">SignUp</Link></li>
                     <li><Link to="/welcome">Back</Link></li>
                     </div>
                    </nav>
                </header>
            </div>
        )
    }
}

export default HeaderComponent