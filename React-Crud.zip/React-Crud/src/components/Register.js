import React from 'react';
import ReactDOM from 'react-dom';

export class Register extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userName: '',
      age: null,
      address: '',
      country: '',
      gender: ''
    };
        this.changeHandler = this.changeHandler.bind(this);
        //this.changeAgeHandler = this.changeAgeHandler.bind(this);
        //this.changeGenderHandler = this.changeGenderHandler.bind(this);
        //this.changeCountryHandler = this.changeCountryHandler.bind(this);
        //this.changeAddressHandler = this.changeAddressHandler.bind(this);
        this.saveUser = this.saveUser.bind(this);
  }
  changeHandler = (event) => {
    let name = event.target.name;
    let value = event.target.value;
    this.setState({[name]: value});
    //alert(nam +" "+val)
  }
  /*changeUserNameHandler= (event) => {
    this.setState({userName: event.target.value});
}

changeAgeHandler= (event) => {
    this.setState({age: event.target.value});
}

changeGenderHandler= (event) => {
  alert('radio button clicked'+event.target.value);
    this.setState({gender: event.target.value});
}
changeCountryHandler= (event) => {
  alert('drop down clicked'+event.target.value);
    this.setState({country: event.target.value});
}
changeAddressHandler= (event) => {
    this.setState({address: event.target.value});
}*/
  saveUser = (e) => {
    e.preventDefault();
    let user = {userName: this.state.userName, age: this.state.age, gender: this.state.gender,address: this.state.address,country:this.state.country};
    //console.log('USer => ' + JSON.stringify(user));
    alert('USer => ' + JSON.stringify(user));
  }
  render() {
    return (
      <form >
     
      <p>Enter your name:</p>
      <input
        type='text'
        name='userName' 
        onChange={this.changeHandler}
      />
      <p>Enter your age:</p>
      <input
        type='text'
        name='age' 
        onChange={this.changeHandler}
      />
      <br/>
      <p>Enter your address</p>
      <textarea name="address" value={this.state.address} onChange={this.changeHandler}/>
      <br/>
      <p>Enter your Country</p>
      <select name="country" value={this.state.country} onChange={this.changeHandler}>
        <option value="India">India</option>
        <option value="US">US</option>
        <option value="UK">UK</option>
      </select> <br></br>
      <p>Gender</p>
            <input type="radio" name="gender" value="Female"  onChange={this.changeHandler}/>Female
            <input type="radio" name="gender" value="Male"   onChange={this.changeHandler}/>Male
         
      <input type='submit' onClick={this.saveUser}/>
      </form>
    );
  }
}
export default Register;