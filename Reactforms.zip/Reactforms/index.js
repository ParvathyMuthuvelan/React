import React from 'react';
import ReactDOM from 'react-dom';
import Register from './Register'


ReactDOM.render(<Register />, document.getElementById('root'));
